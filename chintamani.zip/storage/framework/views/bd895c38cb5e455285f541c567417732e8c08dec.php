<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>

<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/js/owl-custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/data-table/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/data-table/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/data-table/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/bower_components/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/bower_components/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/data-table/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/data-table/js/data-table-custom.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/switchery/dist/switchery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/pages/advance-elements/swithces.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/wysiwyg-editor/wysiwyg-editor.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/js/modal.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/js/modalEffects.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/modernizr/modernizr.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/modernizr/feature-detects/css-scrollbars.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/bower_components/chart.js/dist/Chart.js')); ?>"></script>
<script src="developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js')}}"></script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/pages/google-maps/gmaps.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/widget/gauge/gauge.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/widget/amchart/amcharts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/widget/amchart/serial.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/widget/amchart/gauge.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/widget/amchart/pie.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/pages/widget/amchart/light.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/js/pcoded.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/js/vartical-layout.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/files/assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/pages/dashboard/crm-dashboard.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/files/assets/js/script.js')); ?>"></script>
<script src="https://use.fontawesome.com/7223a10777.js"></script>

<script>
  $(document).ready(function() {
    $('#example').DataTable({
      // Your DataTable options go here
      // For example:
      "paging": true,
      "ordering": true,
      // Other options...
    });
  });
</script>
</body>

</html><?php /**PATH F:\xampp\htdocs\chintamani\resources\views/admin/includes/footer_script.blade.php ENDPATH**/ ?>