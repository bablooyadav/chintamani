<nav class="pcoded-navbar">
   <div class="pcoded-inner-navbar main-menu">
      <div class="pcoded-navigatio-lavel">Navigation</div>
      <ul class="pcoded-item pcoded-left-item">
         <li class=" active pcoded-trigger">
            <a href="<?php echo e(route('index')); ?>">
               <span class="pcoded-micon"><i class="fa fa-home"></i></span>
               <span class="pcoded-mtext">Dashboard</span>
            </a>
         </li>
         <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
               <span class="pcoded-micon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></span>
               <span class="pcoded-mtext">User</span>
            </a>
            <ul class="pcoded-submenu">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-read')): ?>
               <li>
                  <a href="<?php echo e(route('users')); ?>">
                     <span class="pcoded-mtext">Add User</span>
                  </a>
               </li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-read')): ?>
               <li>
                  <a href="<?php echo e(route('roles')); ?>">
                     <span class="pcoded-mtext">Add Roles</span>
                  </a>
               </li>
               <?php endif; ?>
               <li class>
                  <a href="login-info.php">
                     <span class="pcoded-mtext">Login Info</span>
                  </a>
               </li>
            </ul>
         </li>
         <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
               <span class="pcoded-micon"><i class="fa fa-users" aria-hidden="true"></i></span>
               <span class="pcoded-mtext">CMS</span>
            </a>
            <ul class="pcoded-submenu">
               <li class="pcoded-hasmenu">
                  <a href="javascript:void(0)">
                     <span class="pcoded-mtext">Home</span>
                  </a>
                  <ul class="pcoded-submenu">
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('slider-read')): ?>
                     <li>
                        <a href="<?php echo e(route('slider')); ?>">
                           <span class="pcoded-mtext">Slider </span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('financialspecialists-read')): ?>
                     <li>
                        <a href="<?php echo e(route('financial-specialists')); ?>">
                           <span class="pcoded-mtext">Finincial Specilist</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('yourachivements-read')): ?>
                     <li>
                        <a href="<?php echo e(route('your-achivements')); ?>">
                           <span class="pcoded-mtext">Your Achivements</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('whychoosechintamani-read')): ?>
                     <li>
                        <a href="<?php echo e(route('why-choose-chintamani')); ?>">
                           <span class="pcoded-mtext">Why Choose Us</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('becomepartner-read')): ?>
                     <li>
                        <a href="<?php echo e(route('become-partner')); ?>">
                           <span class="pcoded-mtext">Become a Partner</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supportcustomer-read')): ?>
                     <li>
                        <a href="<?php echo e(route('support-customer')); ?>">
                           <span class="pcoded-mtext">Support</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('whoweare-read')): ?>
                     <li>
                        <a href="<?php echo e(route('who-we-are')); ?>">
                           <span class="pcoded-mtext">Who We Are</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('getfreescore-read')): ?>
                     <li>
                        <a href="<?php echo e(route('get-free-score')); ?>">
                           <span class="pcoded-mtext">Get Free Score</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faq-read')): ?>
                     <li>
                        <a href="<?php echo e(route('faq')); ?>">
                           <span class="pcoded-mtext">FAQs</span>
                        </a>
                     </li>
                     <?php endif; ?>
                  </ul>
               </li>
               <li class=" pcoded-hasmenu">
                  <a href="javascript:void(0)">
                     <span class="pcoded-mtext">About</span>
                  </a>
                  <ul class="pcoded-submenu">
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('about-read')): ?>
                     <li>
                        <a href="<?php echo e(route('about')); ?>">
                           <span class="pcoded-mtext">About Us</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('whychooseus-read')): ?>
                     <li>
                        <a href="<?php echo e(route('why-choose-us')); ?>">
                           <span class="pcoded-mtext">Why Choose Us</span>
                        </a>
                     </li>
                     <?php endif; ?>
                  </ul>
               </li>

               <li class=" pcoded-hasmenu">
                  <a href="javascript:void(0)">
                     <span class="pcoded-mtext">Loan Type</span>
                  </a>
                  <ul class="pcoded-submenu">
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loanTypeServices-read')): ?>
                     <li>
                        <a href="<?php echo e(route('loan-type-services')); ?>">
                           <span class="pcoded-mtext">Loan Type Services</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-read')): ?>
                     <li>
                        <a href="<?php echo e(route('category')); ?>">
                           <span class="pcoded-mtext">Category</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subcategory-read')): ?>
                     <li>
                        <a href="<?php echo e(route('sub-category')); ?>">
                           <span class="pcoded-mtext">Sub Category</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('city-read')): ?>
                     <li>
                        <a href="<?php echo e(route('city')); ?>">
                           <span class="pcoded-mtext">City</span>
                        </a>
                     </li>
                     <?php endif; ?>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('citypages-read')): ?>
                     <li>
                        <a href="<?php echo e(route('city-pages')); ?>">
                           <span class="pcoded-mtext">City pages</span>
                        </a>
                     </li>
                     <?php endif; ?>
                  </ul>
               </li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ourblogs-read')): ?>
               <li>
                  <a href="<?php echo e(route('our-blogs')); ?>">
                     <span class="pcoded-mtext">Blog</span>
                  </a>
               </li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('career-read')): ?>
               <li>
                  <a href="<?php echo e(route('career')); ?>">
                     <span class="pcoded-mtext">Career</span>
                  </a>
               </li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact-read')): ?>
               <li>
                  <a href="<?php echo e(route('contact')); ?>">
                     <span class="pcoded-mtext">Contact</span>
                  </a>
               </li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insurances-read')): ?>
               <li>
                  <a href="<?php echo e(route('insurances')); ?>">
                     <span class="pcoded-mtext">Insurances</span>
                  </a>
               </li>
               <?php endif; ?>
            </ul>
         </li>
         <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
               <span class="pcoded-micon"><i class="fa fa-address-book-o" aria-hidden="true"></i></span>
               <span class="pcoded-mtext">LMS</span>
            </a>
            <ul class="pcoded-submenu">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry-read')): ?>
               <li>
                  <a href="<?php echo e(route('enquiry')); ?>">
                     <span class="pcoded-mtext">Enquiries</span>
                  </a>
               </li>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ManualLeads-read')): ?>
               <li>
                  <a href="<?php echo e(route('manual-leads')); ?>">
                     <span class="pcoded-mtext">Manual Leads</span>
                  </a>
               </li>

               <?php endif; ?>
               <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rejection-read')): ?>
               <li>
                  <a href="<?php echo e(route('rejection')); ?>">
                     <span class="pcoded-mtext">Enquiry Rejection</span>
                  </a>
               </li>
               <?php endif; ?> -->
            </ul>
         </li>

          <li>
            <a href="<?php echo e(route('viewcontact.enquiry')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">View Contact Enquiry</span>
            </a>
         </li>
          <li>
            <a href="<?php echo e(route('allwebenquiry.enquiry')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Web Enquiry</span>
            </a>
         </li>
          <li>
            <a href="<?php echo e(route('lead.management')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Lead Management</span>
            </a>
         </li>

         <li>
            <a href="<?php echo e(route('verification.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Verification</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('appliedloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Applied Loans</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('holdloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Hold Loans</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('processingloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Processing Loans</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('approvedloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Approved Loans</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('rejectedloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Rejected Loans</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('sanctionedloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Sanctioned Loans</span>
            </a>
         </li>
         <li>
            <a href="<?php echo e(route('disbursedloans.loan')); ?>">
               <span class="pcoded-micon"><i class="fa fa-tasks"></i></span>
               <span class="pcoded-mtext">Disbursed Loans</span>
            </a>
         </li>


      </ul>
   </div>
</nav><?php /**PATH F:\xampp\htdocs\chintamani\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>