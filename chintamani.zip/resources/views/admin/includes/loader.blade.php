<!-- <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="{{asset('assets/dist/img/prelogo.png')}}" alt="prelogo" height="267" width="772">
</div> -->