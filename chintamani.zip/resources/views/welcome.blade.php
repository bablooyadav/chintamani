@extends('frontend.layouts.master')

@section('content')


<div id="hero-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-9 col-xs-12 text-center">
                <div class="contents">

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
