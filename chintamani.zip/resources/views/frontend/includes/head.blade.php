<meta charset="utf-8" />
<title></title>
<link rel="shortcut icon" type="images/png" href="images/logo/favicons.png">
<link rel="stylesheet" href="{{asset('frontend/assets/css/animate.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/font-awesome.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/magnific-popup.min.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/color/default.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/editor-style.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/theme.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/meanmenu.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/main.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/widgets.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/responsive.css')}}">
<link rel="stylesheet" href="{{asset('frontend/assets/css/chintamani.css')}}">