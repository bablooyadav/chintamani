<div class="sidebar">
   <aside id="widget-categories" class="widget widget_categories">
      <h5 class="widget-title">Realted Loan Type <span></span></h5>
      <ul>
         <li class="cat-item"><a href="#!">Personal Loan for CA</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for CS</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for Doctors</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for Salaried Employees</a>  </li>
         <li class="cat-item"><a href="#!">Pers.. Loan for Government Employees</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for Home renovation</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for Wedding</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for Travel</a>  </li>
         <li class="cat-item"><a href="#!">Personal Loan for Medical emergency</a>  </li> 
          
      </ul>
   </aside>
   <aside id="widget-text-2" class="widget widget_text">
      <h5 class="widget-title">Need Help? <span></span></h5>
      <div class="textwidget">
         <p class="text-left">Chintamani Finlease Limited is one of the fastest growing
          Financial Company (NBFC) in India. Within a span of 28+ years of operations.</p>
         <h3 class="primary-color text-left"><a href="tel:+91-9212132955">+91-9212132955</a></h3>
      </div>
   </aside>
    <aside id="widget-text" class="widget widget_text">
     <h5 class="widget-title">Social Community <span></span></h5>
     <div class="textwidget">
         <div class="textwidget_img">
             <img src="assets/images/sidebar/about_me.png" alt="about_me" class="rounded-circle">
             <div class="circles-spin">
                 <div class="circle-one"></div>
             </div>
         </div>
         <h6>Well Hi There, I'm Online</h6>
         <p>online social community is a group of Chintamani Finlease Limited .</p>
         <aside class="share-toolkit widget widget_social_widget"> 
             <ul>
                 <li><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                 <li><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                 <li><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
                 <li><a href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
             </ul>
         </aside>
     </div>
 </aside>
</div>